#!/bin/bash
service nginx stop
