#!/bin/bash
apt-get install -y nginx-full uwsgi uwsgi-plugin-python
rm /etc/nginx/sites-available/default
if [ -d "/data"]
then
  mkdir /data
else
fi
