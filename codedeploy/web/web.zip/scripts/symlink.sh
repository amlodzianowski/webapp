#!/bin/bash
ln -s /etc/nginx/sites-available/sites-default /etc/nginx/sites-enabled/sites-default
